const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, 'bachathon.db'));
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'seeker',
 skills TEXT DEFAULT '',
 bio TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS jobs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 company TEXT NOT NULL,
 category TEXT NOT NULL,
 location TEXT DEFAULT 'Remote',
 type TEXT DEFAULT 'Part-time',
 description TEXT NOT NULL,
 skills TEXT DEFAULT '',
 verified INTEGER DEFAULT 1,
 employer_id INTEGER,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(employer_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS applications (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 job_id INTEGER NOT NULL,
 user_id INTEGER NOT NULL,
 cover_note TEXT DEFAULT '',
 status TEXT DEFAULT 'Applied',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(job_id,user_id),
 FOREIGN KEY(job_id) REFERENCES jobs(id),
 FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

const count = db.prepare('SELECT COUNT(*) c FROM jobs').get().c;
if (!count) {
 const seed = db.prepare(`INSERT INTO jobs(title,company,category,location,type,description,skills) VALUES(?,?,?,?,?,?,?)`);
 [
  ['Online Data Annotator','Bachathon AI Projects','Data Annotation','Worldwide','Part-time','Label and review text, image, and audio data for AI systems.','Attention to detail, English, data labeling'],
  ['Content Moderator','Global Tech Partner','Content Moderation','Multiple regions','Full-time','Review digital content against clear community and safety guidelines.','English, judgment, communication'],
  ['Customer Support Specialist','E-commerce Company','Customer Experience','Worldwide','Part-time','Support customers through chat and email while documenting resolutions.','Customer service, writing, computer skills'],
  ['Search Quality Evaluator','AI Research Partner','Artificial Intelligence','Multiple regions','Part-time','Evaluate search results and provide structured quality feedback.','Research, web skills, critical thinking'],
  ['Virtual Assistant','Digital Agency','Administrative','Worldwide','Part-time','Assist with scheduling, research, inbox management and routine admin tasks.','Organization, communication, spreadsheets']
 ].forEach(j=>seed.run(...j));
}

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({secret:process.env.SESSION_SECRET || 'bachathon-ai-development-secret',resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:1000*60*60*24*7}}));
app.use(express.static(path.join(__dirname,'public')));

function auth(req,res,next){ if(!req.session.userId) return res.status(401).json({error:'Please log in first.'}); next(); }
function user(req){ return db.prepare('SELECT id,name,email,role,skills,bio,created_at FROM users WHERE id=?').get(req.session.userId); }

app.get('/api/me',(req,res)=>res.json({user:req.session.userId?user(req):null}));
app.post('/api/register',(req,res)=>{
 const {name,email,password,role='seeker'}=req.body;
 if(!name||!email||!password) return res.status(400).json({error:'Name, email and password are required.'});
 if(password.length<8) return res.status(400).json({error:'Password must be at least 8 characters.'});
 if(!['seeker','employer'].includes(role)) return res.status(400).json({error:'Invalid account type.'});
 try { const hash=bcrypt.hashSync(password,12); const info=db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)').run(name,email.toLowerCase(),hash,role); req.session.userId=info.lastInsertRowid; res.status(201).json({user:user(req)}); }
 catch(e){ res.status(409).json({error:'An account with that email already exists.'}); }
});
app.post('/api/login',(req,res)=>{
 const {email,password}=req.body; const u=db.prepare('SELECT * FROM users WHERE email=?').get((email||'').toLowerCase());
 if(!u||!bcrypt.compareSync(password||'',u.password_hash)) return res.status(401).json({error:'Invalid email or password.'});
 req.session.userId=u.id; res.json({user:user(req)});
});
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.put('/api/profile',auth,(req,res)=>{
 const {name,skills,bio}=req.body; db.prepare('UPDATE users SET name=?,skills=?,bio=? WHERE id=?').run(name||'',skills||'',bio||'',req.session.userId); res.json({user:user(req)});
});

app.get('/api/jobs',(req,res)=>{
 const q=(req.query.q||'').trim(); const category=(req.query.category||'').trim();
 let sql='SELECT j.*, u.name employer_name FROM jobs j LEFT JOIN users u ON u.id=j.employer_id WHERE 1=1'; const params=[];
 if(q){sql+=' AND (j.title LIKE ? OR j.company LIKE ? OR j.description LIKE ? OR j.skills LIKE ?)'; const x=`%${q}%`; params.push(x,x,x,x);}
 if(category){sql+=' AND j.category=?';params.push(category);}
 sql+=' ORDER BY j.created_at DESC';
 res.json({jobs:db.prepare(sql).all(...params)});
});
app.get('/api/jobs/:id',(req,res)=>{ const job=db.prepare('SELECT * FROM jobs WHERE id=?').get(req.params.id); if(!job) return res.status(404).json({error:'Job not found.'}); res.json({job}); });
app.post('/api/jobs',auth,(req,res)=>{
 const u=user(req); if(u.role!=='employer') return res.status(403).json({error:'Only employer accounts can post jobs.'});
 const {title,company,category,location,type,description,skills}=req.body;
 if(!title||!company||!category||!description) return res.status(400).json({error:'Title, company, category and description are required.'});
 const info=db.prepare('INSERT INTO jobs(title,company,category,location,type,description,skills,employer_id) VALUES(?,?,?,?,?,?,?,?)').run(title,company,category,location||'Remote',type||'Part-time',description,skills||'',u.id);
 res.status(201).json({job:db.prepare('SELECT * FROM jobs WHERE id=?').get(info.lastInsertRowid)});
});
app.post('/api/jobs/:id/apply',auth,(req,res)=>{
 const u=user(req); if(u.role!=='seeker') return res.status(403).json({error:'Only job seeker accounts can apply.'});
 const job=db.prepare('SELECT id FROM jobs WHERE id=?').get(req.params.id); if(!job) return res.status(404).json({error:'Job not found.'});
 try { db.prepare('INSERT INTO applications(job_id,user_id,cover_note) VALUES(?,?,?)').run(job.id,u.id,req.body.cover_note||''); res.status(201).json({message:'Application submitted.'}); }
 catch(e){res.status(409).json({error:'You have already applied for this job.'});}
});
app.get('/api/applications',auth,(req,res)=>{
 const rows=db.prepare(`SELECT a.*,j.title,j.company,j.category FROM applications a JOIN jobs j ON j.id=a.job_id WHERE a.user_id=? ORDER BY a.created_at DESC`).all(req.session.userId); res.json({applications:rows});
});
app.get('/api/employer/applications',auth,(req,res)=>{
 const u=user(req); if(u.role!=='employer') return res.status(403).json({error:'Employer account required.'});
 const rows=db.prepare(`SELECT a.*,j.title,j.company,u.name candidate_name,u.email candidate_email FROM applications a JOIN jobs j ON j.id=a.job_id JOIN users u ON u.id=a.user_id WHERE j.employer_id=? ORDER BY a.created_at DESC`).all(u.id); res.json({applications:rows});
});
app.patch('/api/applications/:id',auth,(req,res)=>{
 const u=user(req); if(u.role!=='employer') return res.status(403).json({error:'Employer account required.'});
 const appRow=db.prepare(`SELECT a.id FROM applications a JOIN jobs j ON j.id=a.job_id WHERE a.id=? AND j.employer_id=?`).get(req.params.id,u.id); if(!appRow) return res.status(404).json({error:'Application not found.'});
 const allowed=['Applied','Under Review','Accepted','Rejected']; if(!allowed.includes(req.body.status)) return res.status(400).json({error:'Invalid status.'}); db.prepare('UPDATE applications SET status=? WHERE id=?').run(req.body.status,req.params.id); res.json({ok:true});
});

app.use((req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Bachathon AI running at http://localhost:${PORT}`));
